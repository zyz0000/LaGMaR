## TensorReg Toolbox for Matlab

TensorReg toolbox is a collection of Matlab functions for tensor regressions. 

See the [software webpage](http://hua-zhou.github.io/TensorReg/) for installation guide and tutorials. 
