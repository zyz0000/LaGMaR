# MATLAB Tensor Toolbox (by Tamara Kolda)

Version: 2.6

Official documentation: http://www.sandia.gov/~tgkolda/TensorToolbox/
